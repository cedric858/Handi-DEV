@extends('layouts.admin')
@endsection('content')
<h1>Liste des utilisateurs</h1>
@endsection