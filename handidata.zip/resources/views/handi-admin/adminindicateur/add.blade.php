@extends('layouts.admin')
@section('content')
<p>
    Formulaire de création d'indicateur
</p>
@endsection