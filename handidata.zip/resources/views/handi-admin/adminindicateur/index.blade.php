<h1>Les indicateurs</h1>
@forelse($items as $item)
    {{ $item->libelle }}
    <div >
        1

    </div>
    <div >
        2

    </div>
    <div >
        3

    </div>
    <div >
        4

    </div>
    <div >
        5

    </div>
    <div >
        5

    </div>


    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>
    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>


    <div >
        5

    </div>




    <div id="16">
        Voici ce da,md,amld,azmld,azmld,amld,alz,md,amzl

    </div>
    @empty
    <p>
        Rien a afficher
    </p>
@endforelse