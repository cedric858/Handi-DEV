<?php $__env->startSection('header'); ?>
    Mise à jour de <strong><?php echo e($item->libelle); ?></strong> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="/admin">Accueil</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('domaines.index')); ?>">Liste des domaines</a></li>
    <li class="breadcrumb-item active">Mise à jour de <?php echo e($item->libelle); ?></li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!--Header domaine details-->
<div class="row no-gutters">
    <div class="col-sm-12 col-md-4">
        <div class="card card-primary text-center">
            <div class="card-header">
                <h3 class="card-title">
                    Nombre d'indicateurs de ce domaine
                </h3>


            </div>
            <div class="card-body ">

                <h3>
                    <?php echo e($item->indicateurs->count()); ?>

                </h3>

            </div>
            <div class="card-footer">
                <?php if($item->indicateurs->count() == 0): ?>
                    <a href="<?php echo e(route('indicateurs.create')); ?>" class="btn btn-info" title="Créer un indicateur"><i class="fas fa-plus"></i> En créer</a>
                    
                <?php else: ?>
                <a href="<?php echo e(route('indicateurs.list')); ?>" class="btn btn-info" title="Voir les indicateurs de ce domaine"><i class="fas fa-plus"></i> Aller aux indicateurs</a>
                    
                <?php endif; ?>
                

            </div>

        </div>
       


    </div>
    <div class="col-sm-12 col-md-8 pl-3">
        <h2 >Description</h2>
        <p><?php echo e($item->description); ?></p>
        
        


    </div>
        
</div>
    <div class="row">
        <div class="col-md-8 col-offset-2">
            <div class="card">
                <div class="card-header">
                    <h3> <i class="fas fa-"></i> Mise à jour des détails</h3>

                </div>
                <div class="card-body">
                        <form action="<?php echo e(route('domaines.update',$item->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            
                            <div class="form-group">
                                <label for="libelle">Libellé:</label> 
                                <input aria-describedby="errorlibelle" type="text" 
                                class="form-control <?php $__errorArgs = ['libelle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> "
                                 name="libelle" value="<?php echo e(old('libelle',$item->libelle)); ?>">
                                <?php $__errorArgs = ['libelle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="form-text text-danger" id='errorlibelle'>
                                        <?php echo e($errors->first('libelle')); ?>


                                    </small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="description">Description</label>
                        
                                <textarea aria-describedby="errordescription" name="description" 
                                class="form-control " 
                                id="" cols="30" rows="10"><?php echo e(old('description',$item->description)); ?></textarea>




                            </div>
                            <input type="submit" value="Mettre à jour" class="btn btn-warning">

                            
                        </form>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\handidata\resources\views/handi-admin/admindomaine/edit.blade.php ENDPATH**/ ?>