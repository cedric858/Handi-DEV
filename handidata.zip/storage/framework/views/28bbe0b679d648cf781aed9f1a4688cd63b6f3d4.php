<?php
$increment = 1;
?>

<?php $__env->startSection('header'); ?>
    Liste des domaines
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="/admin">Accueil</a></li>
    <li class="breadcrumb-item active">Liste des domaines</li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <div class="row no-gutters">
        <div class="col-sm-12 col-md-4">
            <div class="card card-primary text-center">
                <div class="card-header">
                    <h3 class="card-title">
                        Nombre de domaines 
                    </h3>
                    

                </div>
                <div class="card-body ">

                    <h3>
                        <?php echo e($nbrItems); ?>

                    </h3>

                </div>
                <div class="card-footer">
                    <a href="<?php echo e(route('domaines.create')); ?>" class="btn btn-info" title="Ajouter un domaine"><i class="fas fa-plus"></i> En créer</a>

                </div>

            </div>
           


        </div>
        <div class="col-sm-12 col-md-8 pl-3">
            <h2 >Indication sur les domaines</h2>
            <p>Les domaines réunissent les structures étatiques, les entreprises prise qui partagent   des activités économiques similaires</p>
            <p >
                Les indicateurs définis par domaine permettent un suivi de la convention pour la promotion des personnes handicapées
            </p>
            


        </div>
            
    </div>
    <!--/Header domaine-->
    <!--Liste des domaines-->
    <div class="row">
        <div class="col-sm-12 mt-3">
            
            <?php if($message = Session::get('success')): ?>
              <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>    
                    <strong><?php echo e($message); ?></strong>
              </div>
            <?php endif; ?>
            <?php if($message = Session::get('error')): ?>
              <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>    
                    <strong><?php echo e($message); ?></strong>
              </div>
            <?php endif; ?>

        </div>
    </div>

    
<div class="card">
        <div class="card-header">
            <h4 class="card-title">
               Liste des domaines
            </h4>

        </div>
        <div class="card-body" >
            <table class="table">
                <thead>
                    <tr>
                        <th>
                            #
                        </th>
                        <th>
                            Libellé du domaine
                        </th>
                        <th>
                            Actions
                        </th>

                    </tr>

                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <?php echo e($increment); ?>

                        </td>
                        <td>
                            <?php echo e($item->libelle); ?>

                        </td>
                        <td>
                            <a href="<?php echo e(route('domaines.show',$item->id)); ?>" class="btn btn-info">
                                <i class="fas fa-eye"></i> Voir détails
                            </a>
                            <a href="<?php echo e(route('domaines.edit',$item->id)); ?>" class="btn btn-warning">
                                <i class="fas fa-pencil-alt"></i> Modifier
                            </a>
                           
                              <form action="<?php echo e(route('domaines.destroy',$item->id)); ?>" method="post" style="display:inline" onsubmit="return confirm('Vous êtes sûr?');">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="_method" value="DELETE">
                                <button class="btn btn-danger"><i class="fa fa-pencil"></i>  Supprimer</button>
                
                            </form>
                        </td>
                    </tr>
                    <?php $increment +=1 ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="badge badge-danger" >Pas de domaine</p>
                        
                    <?php endif; ?>


                </tbody>
                <tfoot>
                    <?php echo e($items->links()); ?>


                </tfoot>
            </table>
        </div>
    </div>
        


    

        
        




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\handidata\resources\views/handi-admin/admindomaine/index.blade.php ENDPATH**/ ?>