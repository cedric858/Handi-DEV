<?php
$increment = 1;
?>

<?php $__env->startSection('header'); ?>
    Liste des langues
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="/admin">Accueil</a></li>
    <li class="breadcrumb-item active">Liste des langues</li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <div class="row no-gutters">
        <div class="col-sm-12 col-md-4">
            <div class="card card-primary text-center">
                <div class="card-header">
                    <h3 class="card-title">
                        Nombre de langues 
                    </h3>
                    

                </div>
                <div class="card-body ">

                    <h3>
                        <?php echo e($nbrItems); ?>

                    </h3>

                </div>
                <div class="card-footer">
                    <a href="<?php echo e(route('langues.create')); ?>" class="btn btn-info" title="Ajouter une langue"><i class="fas fa-plus"></i> En créer</a>

                </div>

            </div>
            


        </div>
        <div class="col-sm-12 col-md-8 pl-3">
            <h2 >Indication sur les langues parlées au Burkina Faso</h2>
            <p>La langue officielle du Burkina Faso est le français. Le nom même du pays est métissé de deux langues différentes : "burkina" en mooré veut dire "intègre" et "faso" en bambara signife "patrie", d'où son surnom de Pays des hommes intègres.
Le nombre de peuples et d’ethnies au Burkina révèle le nombre de langues ou de dialectes pratiqués.Il existe tout de même plus de 60 langues et dialectes dont les principales sont: le mooré langue parlée par l’ethnie Mossi, le san parlé par les Samos, le fulfuldé parlé par les Peuls, le gulmancéma parlé par les Gourmantché dans l'Est du Burkina Faso, le dagara parlé par les Dagaris, le Dioula qui est une langue commune à plusieurs pays d’Afrique de l’ouest (la Côte d’Ivoire, le Mali, la Guinée etc…), le lobiri parlé par les lobis, le marka, le bobo, le bwamu parlé par les bwabas, le senoufo, le Toussian parlé par les Toussians, le kassena et le lyélé (langues parlées par le peuple dit Gourounsi qui en réalité s'appelle lui-même "NOUN", sud-est et centre ouest) et le bissa qui est la langue parlée par l’ethnie des Boussancé appelé couramment Bissas.</p>
            


        </div>
            
    </div>
    <!--/Header langue-->
    <!--Liste des langues-->
    <div class="row">
        <div class="col-sm-12 mt-3">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Liste des langues
                        <?php echo e($items->links()); ?>

                    </h4>
                    <?php if($message = Session::get('success')): ?>
              <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>    
                    <strong><?php echo e($message); ?></strong>
              </div>
            <?php endif; ?>
            <?php if($message = Session::get('error')): ?>
              <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>    
                    <strong><?php echo e($message); ?></strong>
              </div>
            <?php endif; ?>


                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>
                                    #
                                </th>
                                <th>
                                    Libellé
                                </th>
                                <th>
                                    Actions
                                </th>
                            </tr>

                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <th>
                                    <?php echo e($increment); ?>

                                </th>
                                <td>
                                    <?php echo e($item->libelle); ?>

                                </td>
                                <td>
                                    <a href="<?php echo e(route('langues.show',$item->id)); ?>" class="btn btn-info">
                                        <i class="fas fa-eye"></i> Voir détails
                                    </a>
                                    <a href="<?php echo e(route('langues.edit',$item->id)); ?>" class="btn btn-warning">
                                        <i class="fas fa-pencil-alt"></i> Modifier
                                    </a>
                                   
                                      <form action="<?php echo e(route('langues.destroy',$item->id)); ?>" method="post" style="display:inline" onsubmit="return confirm('Vous êtes sûr?');">
                                        <?php echo e(csrf_field()); ?>

                                        <input type="hidden" name="_method" value="DELETE">
                                        <button class="btn btn-danger"><i class="fa fa-pencil"></i>  Supprimer</button>
                        
                                    </form>
                                </td>

                            </tr>
                            <?php $increment +=1; ?>
                                
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="badge badge-alert">
                                Pas de langues
                            </p>
                                
                            <?php endif; ?>
                        </tbody>
                    </table>

                </div>
                <div class="card-footer">
                    <?php echo e($items->links()); ?>


                </div>
            </div>
            
            

        </div>
    </div>
    
    
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\handidata\resources\views/handi-admin/adminlangue/index.blade.php ENDPATH**/ ?>