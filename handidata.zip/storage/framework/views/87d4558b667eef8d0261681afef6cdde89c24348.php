<h1>Les indicateurs</h1>
<?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php echo e($item->libelle); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p>
        Rien a afficher
    </p>
<?php endif; ?><?php /**PATH C:\handidata\resources\views/handi-admin/admindicateur/index.blade.php ENDPATH**/ ?>