<?php $__env->startSection('header'); ?>
    Détails de <strong><?php echo e($item->libelle); ?></strong> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="/admin">Accueil</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('regions.index')); ?>">Liste régions</a></li>
    <li class="breadcrumb-item active">Détails de <?php echo e($item->libelle); ?></li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-sm-4 text-center">
    <div class="card card-primary">
        <div class="card-header">
            <h4 class="card-title">
                <?php echo e($item->libelle); ?>

            </h4>

        </div>
        <div class="card-body" >
            
               
                    <p>
                        Nombre de chef-lieux de cette région:
                    </p>
                    <h3><?php echo e($item->cheflieu()->count()); ?></h3>
                        
                     
                    <a href="<?php echo e(route('cheflieus.index',['region'=>$item->id])); ?>" class="btn btn-info" title="Aller au chef-lieux"><i class="fas fa-arrow-circle-right"></i> Allez aux chef-lieux</a>

                
            
        </div>
    </div>

</div>

    <div class="row">
        <div class="col-md-8 col-offset-2">
            <div class="card">
                <div class="card-header">
                    <h3> <i class="fas fa-"></i> Les détails</h3>

                </div>
                <div class="card-body">
                        <form action="" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="libelle">Libellé:</label> 
                                <input aria-describedby="errorlibelle" type="text" 
                                class="form-control <?php $__errorArgs = ['libelle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> "
                                 name="libelle" value="<?php echo e($item->libelle); ?>" disabled>
                            </div>
                        </form>
                        <a href="<?php echo e(route('regions.edit',$item->id)); ?>" class="btn btn-warning" title="Modifier"><i class="fas fa-pencil"></i> Modifier</a>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\handidata\resources\views/handi-admin/adminregion/show.blade.php ENDPATH**/ ?>