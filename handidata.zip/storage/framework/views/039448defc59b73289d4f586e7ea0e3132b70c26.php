<?php $__env->startSection('header'); ?>
Détails de <strong><?php echo e($commune->libelle); ?></strong>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="/admin">Accueil</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('communes.index')); ?>">Liste des communes</a></li>
    <li class="breadcrumb-item active">Détails de <strong><?php echo e($commune->libelle); ?></strong></li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-8 col-offset-2">
            <div class="card">
                <div class="card-header">
                    <h3> <i class="fas fa-"></i> Les détails</h3>

                </div>
                <div class="card-body">
                        <form action="" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="region_id">Province:</label> 
                                <input aria-describedby="errorregion_id" type="text" 
                                class="form-control <?php $__errorArgs = ['cheflieu_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> "
                                 name="region_id" value="<?php echo e($commune->province->libelle); ?>" disabled>
                            </div>
                           

                            <div class="form-group">
                                <label for="libelle">Libellé:</label> 
                                <input aria-describedby="errorlibelle" type="text" 
                                class="form-control "
                                 name="libelle" value="<?php echo e($commune->libelle); ?>" disabled>
                            </div>


                        </form>
                        <a href="<?php echo e(route('communes.edit',$commune->id)); ?>" class="btn btn-warning" title="Modifier"><i class="fas fa-pencil"></i> Modifier</a>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\handidata\resources\views/handi-admin/admincommune/show.blade.php ENDPATH**/ ?>