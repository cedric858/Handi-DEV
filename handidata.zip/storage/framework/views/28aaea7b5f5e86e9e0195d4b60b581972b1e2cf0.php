<h1>Les indicateurs</h1>
<?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php echo e($item->libelle); ?>

    <div >
        1

    </div>
    <div >
        2

    </div>
    <div >
        3

    </div>
    <div >
        4

    </div>
    <div >
        5

    </div>
    <div >
        5

    </div>


    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>
    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>

    <div >
        5

    </div>


    <div >
        5

    </div>




    <div id="16">
        Voici ce da,md,amld,azmld,azmld,amld,alz,md,amzl

    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p>
        Rien a afficher
    </p>
<?php endif; ?><?php /**PATH C:\handidata\resources\views/handi-admin/adminindicateur/index.blade.php ENDPATH**/ ?>