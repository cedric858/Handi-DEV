<?php
$increment = 1;
?>

<?php $__env->startSection('header'); ?>
    Liste des régions
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="/admin">Accueil</a></li>
    <li class="breadcrumb-item active">Liste des Régions</li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!--Header région-->
<div class="row no-gutters">
    <div class="col-sm-12 col-md-4">
        <div class="card card-primary text-center">
            <div class="card-header">
                <h3 class="card-title">
                    Nombre de régions
                </h3>
                

            </div>
            <div class="card-body ">

                <h3>
                    <?php echo e($nbrItems); ?>

                </h3>

            </div>
            <div class="card-footer">
                <a href="<?php echo e(route('regions.create')); ?>" class="btn btn-info" title="Ajouter une région"><i class="fas fa-plus"></i> En créer</a>

            </div>

        </div>
       


    </div>
    <div class="col-sm-12 col-md-8 pl-3">
        <h2 >Indication sur les régions</h2>
        <p>Le Burkina Faso est subdivisé en 13 régions</p>
        


    </div>
        
</div>

<!--Header région-->

    <!--Liste des domaines-->
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">
                Liste des régions
                <?php echo e($items->links()); ?>

            </h4>
            <?php if($message = Session::get('success')): ?>
              <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>    
                    <strong><?php echo e($message); ?></strong>
              </div>
            <?php endif; ?>
            <?php if($message = Session::get('error')): ?>
              <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>    
                    <strong><?php echo e($message); ?></strong>
              </div>
            <?php endif; ?>

        </div>
        <div class="card-body">
            <table class="table">
                <thead>
                    <tr>
                        <th>
                            #
                        </th>
                        <th>
                            Libellé
                        </th>
                        <th>
                            Chefs lieux
                        </th>
                        <th>
                            Actions
                        </th>
                    </tr>

                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <th>
                            <?php echo e($increment); ?>

                        </th>
                        <td>
                            <?php echo e($item->libelle); ?>


                        </td>
                        <td>
                            <?php if($item->cheflieu): ?>
                            <a href="<?php echo e(route('cheflieus.show',$item->cheflieu->id)); ?>" title=" Voir <?php echo e($item->cheflieu->libelle); ?> "><?php echo e($item->cheflieu->libelle); ?></a>
                                
                            <?php else: ?>
                            <p class="badge badge-danger">Pas de chef-lieu pour cette région pour le moment</p>
                                
                            <?php endif; ?>
                         
                            
                            
                        </td>
                        <td>
                            <a href="<?php echo e(route('regions.show',$item->id)); ?>" class="btn btn-info">
                                <i class="fas fa-eye"></i> Voir détails
                            </a>
                            <a href="<?php echo e(route('regions.edit',$item->id)); ?>" class="btn btn-warning">
                                <i class="fas fa-pencil-alt"></i> Modifier
                            </a>
                           
                              <form action="<?php echo e(route('regions.destroy',$item->id)); ?>" method="post" style="display:inline" onsubmit="return confirm('Vous êtes sûr?');">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="_method" value="DELETE">
                                <button class="btn btn-danger"><i class="fa fa-pencil"></i>  Supprimer</button>
                
                            </form>
                        </td>
                    </tr>
                        <?php $increment += 1;  ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="badge badge-danger" >Pas de régions</p>
                        
                    <?php endif; ?>


                </tbody>
                <tfoot>

                </tfoot>
            </table>

        </div>
        <div class="card-footer">
            <?php echo e($items->links()); ?>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\handidata\resources\views/handi-admin/adminregion/index.blade.php ENDPATH**/ ?>