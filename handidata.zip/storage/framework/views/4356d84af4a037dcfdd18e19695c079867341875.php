<?php $__env->startSection('header'); ?>
Mise à jour de <strong><?php echo e($commune->libelle); ?></strong>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="/admin">Accueil</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('communes.index')); ?>">Liste des communes</a></li>
    <li class="breadcrumb-item active">Mise à jour de <strong><?php echo e($commune->libelle); ?></strong></li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
        <div class="card-header">
            <h4 class="card-title">
                Mise à jour
                          </h4>

        </div>
        <div class="card-body" >
            <form action="<?php echo e(route('communes.update',$commune->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <!--Liste des provinces-->
                <div class="form-group">
                    <label for="province_id">Régions <span class="text text-danger">*</span> </label>
                    <select class="form-control" id="province_id" name="province_id">
        
                   
                        <?php $__empty_1 = true; $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option value="<?php echo e($province->id); ?>" <?php
                            if($province->libelle == $commune->province->libelle)
                            {
                                ?>
                                selected

                                <?php
                            }
                            ?> ><?php echo e($province->libelle); ?></option>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="badge badge-danger">Pas de provinces</p>
                            
                        <?php endif; ?> 
                    </select>
        
                            
                       
                      
                      <?php $__errorArgs = ['province_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="help is-danger"><?php echo e($message); ?></p>
                        
                          
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          
                  </div>
        
                <!--/.Liste des provinces-->
               

                <div class="form-group">
                    <label for="libelle">Libellé:</label> 
                    <input aria-describedby="errorlibelle" type="text" 
                    class="form-control "
                     name="libelle" value="<?php echo e(old('libelle',$commune->libelle)); ?>"   >
                </div>
                <input type="submit" value="Mettre à jour" class="btn btn-warning">
            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\handidata\resources\views/handi-admin/admincommune/edit.blade.php ENDPATH**/ ?>