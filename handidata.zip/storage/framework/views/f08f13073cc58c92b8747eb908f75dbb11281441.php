<?php
$increment = 1;
?>


<?php $__env->startSection('header'); ?>
    Liste des Organisations des Personnes Handicapées(OPH)
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="/admin">Accueil</a></li>
    <li class="breadcrumb-item active">Organisations des Personnes Handicapées(OPH)</li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!--Card-->
<div class="row no-gutters">
  <div class="col-sm-12 col-md-4">
      <div class="card card-primary text-center">
          <div class="card-header">
              <h3 class="card-title">
                  Nombre d'organisations de personnes handicapées 
              </h3>


          </div>
          <div class="card-body ">

              <h3>
                  <?php echo e($nbrItems); ?>

              </h3>

          </div>
          <div class="card-footer">
              <a href="<?php echo e(route('ophs.create')); ?>" class="btn btn-info" title="Ajouter une OPH"><i class="fas fa-plus"></i> En créer</a>

          </div>

      </div>
     


  </div>
  <div class="col-sm-12 col-md-8 pl-3">
      <h2 >Indication sur les OPHs</h2>
      <p>Les organisations de personnes handicapées sont des associations de personnes qui fédèrent 
        la communauté des personnes handicapées. Repartis en type de handicaps, ces OPHs mènent des actions sur le terrain afin de promouvoir aux droits des personnes handicapées et veillent à ce qu'ils soient respectés.
      </p>
      
      


  </div>
      
</div>
<!--/Card-->
<!--List des OPHs-->
<div class="row">
    <div class="col-sm-12 mt-3">
        <h3>
            Tableau des OPHs
        </h3>
        <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success alert-block">
              <button type="button" class="close" data-dismiss="alert">×</button>    
              <strong><?php echo e($message); ?></strong>
        </div>
      <?php endif; ?>
      <?php if($message = Session::get('error')): ?>
        <div class="alert alert-danger alert-block">
              <button type="button" class="close" data-dismiss="alert">×</button>    
              <strong><?php echo e($message); ?></strong>
        </div>
      <?php endif; ?>

    </div>
    <?php echo e($items->links()); ?>

    <table class="table table-hover table-striped">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Nom de l'OPH</th>
            <th scope="col">SIGLE</th>
            <th scope="col">Type de handicap</th>
            <th scope="col">Responsable</th>
            <th scope="col">Actions</th>
          </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

          <tr>
            <th  scope="row">
                <?php echo e($increment); ?>

            </th>
            <td><?php echo e($item->nomOph); ?></td>
            <td><?php echo e($item->sigle); ?></td>
            <td>
              <ul>
                <?php $__empty_2 = true; $__currentLoopData = $item->type_handicaps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_handicap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                <li>
                  <?php echo e($type_handicap->libelle); ?>


                </li>
                

                
                

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                <p class="badge badge-danger">Pas de handicap</p>
                <?php endif; ?>
              </ul>
          </td>
            
            <td><?php echo e($item->responsable->prenom); ?>&nbsp;<?php echo e($item->responsable->nom); ?></td>
            <td>
              <a href="<?php echo e(route('ophs.show',$item->id)); ?>" class="btn btn-info">
                <i class="fas fa-eye"></i> Voir détails
            </a>
            <a href="<?php echo e(route('ophs.edit',$item->id)); ?>" class="btn btn-warning">
                <i class="fas fa-pencil-alt"></i> Modifier
            </a>
           
              <form action="<?php echo e(route('ophs.destroy',$item->id)); ?>" method="post" style="display:inline" onsubmit="return confirm('Vous êtes sûr?');">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="_method" value="DELETE">
                <button class="btn btn-danger"><i class="fa fa-pencil"></i>  Supprimer</button>

            </form>
                
            

            </td>
          </tr>
          <?php
              $increment +=1; 
          ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <a href="<?php echo e(route('ophs.create')); ?>" class="btn btn-danger" title="Ajouter OPH">

            Cliquer pour ajouter OPH            
            <span class="badge badge-danger">
                Pas d'OPHs
           </span>

        </a>

              
          <?php endif; ?>

        </tbody>
      </table>
    

</div>
<!--/Liste des OPH-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\handidata\resources\views/handi-admin/adminoph/index.blade.php ENDPATH**/ ?>