<?php $__env->startSection('header'); ?>
    Liste des provinces-ajout
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="/admin">Accueil</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('provinces.index')); ?>">Liste des provinces</a></li>
    <li class="breadcrumb-item active">Liste des provinces-ajout</li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 col-offset-2">
            <div class="card">
                <div class="card-header">
                    <h3> <i class="fas fa-"></i> Nouveau provinces</h3>

                </div>
                <div class="card-body">
                        <form action="<?php echo e(route('provinces.store')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                                                        <!--Chef-lieu-->
        <div class="form-group">
            <label for="cheflieu_id">Chef-lieu <span class="text text-danger">*</span> </label>
            <select class="form-control" id="cheflieu_id" name="cheflieu_id">

           
                <?php $__empty_1 = true; $__currentLoopData = $cheflieus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cheflieu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <option value="<?php echo e($cheflieu->id); ?>"><?php echo e($cheflieu->libelle); ?></option>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="badge badge-danger">Pas de chef-lieu</p>
                    
                <?php endif; ?> 
            </select>

                    
               
              
              <?php $__errorArgs = ['cheflieu_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="help is-danger"><?php echo e($message); ?></p>
                
                  
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  
          </div>


<!--/.chef-lieu-->

                            <div class="form-group">
                                <label for="libelle"  >Libellé:<span class="text text-danger">*</span></label> 
                                <input aria-describedby="errorlibelle" type="text" class="form-control <?php $__errorArgs = ['libelle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="libelle" value="<?php echo e(old('libelle')); ?>">
                                <?php $__errorArgs = ['libelle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="form-text text-danger" id='errorlibelle'>
                                        <?php echo e($errors->first('libelle')); ?>


                                    </small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <button type="submit" class="btn btn-primary mb-2">Créer une province</button>
                        </form>


                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\handidata\resources\views/handi-admin/adminprovince/add.blade.php ENDPATH**/ ?>