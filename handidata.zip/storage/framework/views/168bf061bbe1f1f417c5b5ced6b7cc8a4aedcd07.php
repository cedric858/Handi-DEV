<h1>Les Différentes désagrégations</h1>
<?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    
    <p>Définition: <?php echo e($item->libelle); ?></p>
    <p>Description: <?php echo e($item->description); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p>
        Rien a afficher
    </p>
<?php endif; ?>
<?php echo e($items->links()); ?><?php /**PATH C:\handidata\resources\views/handi-admin/admintypedesagregation/index.blade.php ENDPATH**/ ?>