<?php $__env->startSection('header'); ?>
    Détails de <strong><?php echo e($province->libelle); ?></strong> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="/admin">Accueil</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('provinces.index')); ?>">Liste provinces</a></li>
    <li class="breadcrumb-item active">Détails de <?php echo e($province->libelle); ?></li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-sm-4 text-center">
    <div class="card card-primary">
        <div class="card-header">
            <h4 class="card-title">
                <?php echo e($province->libelle); ?>

            </h4>

        </div>
        <div class="card-body" >
            
               
                    <p>
                        Nombre de communes de cette province:
                    </p>
                    <h3><?php echo e($province->communes()->count()); ?></h3>
                        
                     
                    <a href="<?php echo e(route('communes.index',['region'=>$province->id])); ?>" class="btn btn-info" title="Aller aux communes"><i class="fas fa-arrow-circle-right"></i> Allez aux communes</a>

                
            
        </div>
    </div>

</div>
    <div class="row">
        <div class="col-md-8 col-offset-2">
            <div class="card">
                <div class="card-header">
                    <h3> <i class="fas fa-"></i> Les détails</h3>

                </div>
                <div class="card-body">
                        <form action="" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="region_id">chef-lieu:</label> 
                                <input aria-describedby="errorregion_id" type="text" 
                                class="form-control <?php $__errorArgs = ['cheflieu_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> "
                                 name="region_id" value="<?php echo e($province->cheflieu->libelle); ?>" disabled>
                            </div>
                           

                            <div class="form-group">
                                <label for="libelle">Libellé:</label> 
                                <input aria-describedby="errorlibelle" type="text" 
                                class="form-control "
                                 name="libelle" value="<?php echo e($province->libelle); ?>" disabled>
                            </div>


                        </form>
                        <a href="<?php echo e(route('provinces.edit',$province->id)); ?>" class="btn btn-warning" title="Modifier"><i class="fas fa-pencil"></i> Modifier</a>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\handidata\resources\views/handi-admin/adminprovince/show.blade.php ENDPATH**/ ?>