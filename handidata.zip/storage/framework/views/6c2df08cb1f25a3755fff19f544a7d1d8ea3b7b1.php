<?php $__env->startSection('header'); ?>
    Détails Organisations de Personnes Handicapées
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="/admin">Accueil</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('ophs.index')); ?>">Liste OPHs</a></li>
    <li class="breadcrumb-item active">Détails OPhs</li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title"> <i class="fas fa-"></i> Les détails <a href="<?php echo e(route('ophs.edit',$oph->id)); ?>" class="btn btn-warning">Modifier</a></h3>
                

                </div>
                <div class="card-body">
                    <form action="">
                        <div class="row">
                            <div class="col">
                                <h5>Informations générales </h3>
                                    <div class="form-group">
                                        <label for="nomOph">Nom de l'OPH   : </label>
                                        <input  disabled aria-describedby="errorNomOph" type="text" class="form-control <?php $__errorArgs = ['nomOph'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="nomOph" value="<?php echo e(old('nomOph',$oph->nomOph)); ?>" placeholder="Entrez le nom de l'OPH" >
                                        <?php $__errorArgs = ['nomOph'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="form-text text-danger" id='errorNomOph'>
                                            <?php echo e($errors->first('nomOph')); ?>

                              
                                        </small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              
                                      </div>
                                        <!--Sigle-->
                              
                                      <div class="form-group">
                                          <label for="sigle">Sigle : </label>
                                          <input  disabled aria-describedby="errorSigle" type="text" class="form-control <?php $__errorArgs = ['sigle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="sigle" value="<?php echo e(old('sigle',$oph->sigle)); ?>" placeholder="Entrez le sigle de l'OPH">
                                          <?php $__errorArgs = ['sigle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                          <small class="form-text text-danger" id='errorSigle'>
                                              <?php echo e($errors->first('sigle')); ?>

                                
                                          </small>
                                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                
                                        </div>
                              
                                        <!--/.Sigle-->
                                        <!--Téléphone OPH-->
                                        <div class="form-group">
                                          <label for="telephoneOph">Téléphone de la structure: </label>
                                          <input  disabled aria-describedby="errorTelephoneOph" type="text" class="form-control <?php $__errorArgs = ['telephoneOph'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="telephoneOph" value="<?php echo e(old('telephoneOph',$oph->telephoneOph)); ?>" placeholder="Numéros de Téléphone de l'OPH ">
                                          <?php $__errorArgs = ['telephoneOph'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                          <small class="form-text text-danger" id='telephoneOph'>
                                              <?php echo e($errors->first('telephoneOph')); ?>

                                
                                          </small>
                                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                
                                        </div>
                              
                              
                              
                                        <!--/.Téléphone OPH-->
                              
                                        <!--Mission et objectifs-->
                                        <?php
                                            $missionsArray = explode( "." ,$oph->missionObjectif);
                                            
                                            
                                          ?>
                                        <div class="form-group">
                                          <label for="missionObjectif">Mission et Objectif:</label>
                                          <ul>
                                            <?php $__empty_1 = true; $__currentLoopData = $missionsArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $missionArray): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <li>
                                              <?php echo e($missionArray); ?>

                                                
                                            </li>
                                            
                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <p class="badge badge-danger">Pas de mission ou objectif</p>
                                            <?php endif; ?>
    
                                           </ul>
                                        </div>
                              
                                        
                                        <!--/.Mission et objectifs-->
                              
                                       <!--Type de handicap-->

                                      <div class="form-group">
                                        <label for="type_handicap_id">Type de handicap : </label>
                                        <ul>
                                            <?php $__empty_1 = true; $__currentLoopData = $oph->type_handicaps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type_handicap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <li>
                                                <?php echo e($type_handicap->libelle); ?>

                                            </li>
                                            
                                
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <p class="badge badge-danger">Pas de handicap</p>
                                            <?php endif; ?>

                                        </ul>
                                    </div>
                              
                              
                                       <!--/.Type de handicap-->
                                       <!--Date de création-->
                                       <?php
                                       $date = \Carbon\Carbon::createFromDate($oph->dateCreation) ->format('d-m-Y')
                                       ?>
                                       <div class="form-group">
                                          <label for="dateCreation">Date de création : </label>
                                          <input  disabled type="textp" name="dateCreation" id="dateCreation" value="<?php echo e(old('dateCreation',$date)); ?>">
                              
                              
                                       </div>
                                       <!--/.Date de création-->
                                       <!--domaine-->
                                       <label for="domaine_id">Domaines : </label>
                                       <ul>
                                        <?php $__empty_1 = true; $__currentLoopData = $oph->domaines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $domaine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <li>
                                            <?php echo e($domaine->libelle); ?>

                                        </li>
                                        
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <p class="badge badge-danger">Pas de domaine</p>
                                        <?php endif; ?>

                                       </ul>
                                       
                                       
                              
                                       <!--/.domaine-->
                                       <!--Activité Menée-->
                                       <div class="form-group">
                                          <label for="activite">Activités menées : </label>
                                          <?php
                                            $activitesArray = explode(".",$oph->activite);
                                            
                                          ?>
                                          <ul>
                                            <?php $__empty_1 = true; $__currentLoopData = $activitesArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activiteArray): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <li>
                                            
                                                <?php echo e($activiteArray); ?>

                                            </li>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                             <p class="badge badge-danger">Pas d'activité</p>
                                             <?php endif; ?>

                                          </ul>
                                          
                                    
                                
                                        </div>
                              
                                       <!--/.Activité Menée-->
                                       <!--Bénéficiaires-->
                                       <?php
                                            $beneficiairesArray = explode(".",$oph->beneficiaire);
                                            
                                          ?>
                                       <div class="form-group">
                                          <label for="beneficiaire">Bénéficiaires : </label>
                                          <ul>
                                            <?php $__empty_1 = true; $__currentLoopData = $beneficiairesArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beneficiaireArray): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <li>
                                                <?php echo e($beneficiaireArray); ?>

                                            </li>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                             <p class="badge badge-danger">Pas d'activité</p>
                                             <?php endif; ?>

                                          </ul>
                                          
                                
                                        </div>
                              
                                       <!--/.Bénéficiaires-->
                                       <!--Accessibilité-->
                                       <?php
                                       $accessibilitesArray = explode(".",$oph->accessibilite);
                                       
                                     ?>
                                       <div class="form-group">
                                          <label for="accessibilite">Accéssibilité : </label>
                                          <ul>
                                            <?php $__empty_1 = true; $__currentLoopData = $accessibilitesArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accessibiliteArray): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <li>
                                                <?php echo e($accessibiliteArray); ?>

                                            </li>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                             <p class="badge badge-danger">Pas d'accessibilité</p>
                                             <?php endif; ?>

                                          </ul>
                                          
                                
                                        </div>
                                       <!--/.Accessibilité-->
                                       <!--Source de financement-->
                                       <?php
                                       $sourcesArray = explode(".",$oph->sourceFinancement);
                                       
                                     ?>
                                       <div class="form-group">
                                          <label for="sourceFinancement">Source de Financement : </label>
                                          <ul>
                                            <?php $__empty_1 = true; $__currentLoopData = $sourcesArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sourceArray): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <li>
                                                
                                                <?php echo e($sourceArray); ?>

                                            </li>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                             <p class="badge badge-danger">Pas de sources de financement</p>
                                             <?php endif; ?>

                                          </ul>
                                          
                                
                                        </div>
                              
                                       <!--/.Source de financement-->
                                       <!--Partenaires-->
                                       <div class="form-group">
                                          <label for="partenaire">Partenaires : </label>
                                          <input  disabled aria-describedby="errorPartenaire" type="text" class="form-control <?php $__errorArgs = ['partenaire'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="partenaire" value="<?php echo e(old('partenaire',$oph->partenaire)); ?>" placeholder="Renseignez les partenaires séparés par des points">
                                          <?php $__errorArgs = ['partenaire'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                          <small class="form-text text-danger" id='partenaire'>
                                              <?php echo e($errors->first('partenaire')); ?>

                                
                                          </small>
                                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                
                                        </div>

    
                            </div>
                            <div class="col">
                                <h5>Structuration</h5>
                                <!--Nombre adhérent Homme-->
         <div class="form-group">
            <label for="nbrAdherantHomme">Nombre d'adhérents homme : </label>
            <input   disabled aria-describedby="errorNbrAdherantHomme" min="0"  type="number" class="form-control <?php $__errorArgs = ['nbrAdherantHomme'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="nbrAdherantHomme" value="<?php echo e(old('nbrAdherantHomme',$oph->nbrAdherantHomme)); ?>">
            <?php $__errorArgs = ['nbrAdherantHomme'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="form-text text-danger" id='nbrAdherantHomme'>
                <?php echo e($errors->first('nbrAdherantHomme')); ?>

  
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  
          </div>


         <!--Nombre adhérent Homme-->
         <!--Nombre adhérent Femme-->
         <div class="form-group">
            <label for="nbrAdherantFemme">Nombre d'adhérents femme : </label>
            <input  disabled aria-describedby="errorNbrAdherantFemme" min="0"  type="number" class="form-control <?php $__errorArgs = ['nbrAdherantFemme'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="nbrAdherantFemme" value="<?php echo e(old('nbrAdherantFemme',$oph->nbrAdherantFemme)); ?>">
            <?php $__errorArgs = ['nbrAdherantFemme'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="form-text text-danger" id='nbrAdherantFemme'>
                <?php echo e($errors->first('nbrAdherantFemme')); ?>

  
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  
          </div>


<!--Nombre adhérent Femme-->
<!--Nombre membre Femme-->
<div class="form-group">
    <label for="nbrMembreFemme">Nombre de membres femme : </label>
    <input  disabled aria-describedby="errornNrMembreFemme" min="0"  type="number" class="form-control <?php $__errorArgs = ['nbrAdherantFemme'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="nbrMembreFemme" value="<?php echo e(old('nbrMembreFemme',$oph->nbrMembreFemme)); ?>">
    <?php $__errorArgs = ['nbrMembreFemme'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="form-text text-danger" id='nbrMembreFemme'>
        <?php echo e($errors->first('nbrMembreFemme')); ?>


    </small>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

  </div>


<!--Nombre adhérent Femme-->
<!--Nombre membre Homme-->
<div class="form-group">
    <label for="nbrMembreHomme">Nombre de membres homme : </label>
    <input  disabled aria-describedby="errorNbrMembreHomme" min="0"  type="number" class="form-control <?php $__errorArgs = ['nbrMembreHomme'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="nbrMembreHomme" value="<?php echo e(old('nbrMembreHomme',$oph->nbrMembreHomme)); ?>">
    <?php $__errorArgs = ['nbrMembreHomme'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="form-text text-danger" id='nbrMembreHomme'>
        <?php echo e($errors->first('nbrMembreHomme')); ?>


    </small>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

  </div>


<!--Nombre adhérent Homme-->
<!--Nombre de membre alphabétisé-->
<div class="form-group">
    <label for="nbrMembreAlphabetise">Nombre membres alphabétisés : </label>
    <input  disabled aria-describedby="errorNbrMembreAlphabetise" min="0"  type="number" class="form-control <?php $__errorArgs = ['nbrMembreAlphabetise'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="nbrMembreAlphabetise" value="<?php echo e(old('nbrMembreAlphabetise',$oph->nbrMembreAlphabetise)); ?>">
    <?php $__errorArgs = ['nbrMembreAlphabetise'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="form-text text-danger" id='nbrMembreAlphabetise'>
        <?php echo e($errors->first('nbrMembreAlphabetise')); ?>


    </small>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

  </div>

<!--/.Nombre de membre alphabétisé-->
<!--Nombre de membre alphabétisé-->
<div class="form-group">
    <label for="nbrMembreScolarise">Nombre membres scolarisé : </label>
    <input  disabled aria-describedby="errorNbrMembreScolarise" min="0"  type="number" class="form-control <?php $__errorArgs = ['nbrMembreScolarise'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="nbrMembreScolarise" value="<?php echo e(old('nbrMembreScolarise',$oph->nbrMembreScolarise)); ?>">
    <?php $__errorArgs = ['nbrMembreScolarise'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="form-text text-danger" id='nbrMembreScolarise'>
        <?php echo e($errors->first('nbrMembreScolarise')); ?>


    </small>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>

<!--/.Nombre de membre alphabétisé-->
  <!--Langue-->

  <div class="form-group">
    <label for="langue_id">Langue : </label>
    <?php $__empty_1 = true; $__currentLoopData = $oph->langues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $langue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php echo e($langue->libelle); ?>, &nbsp;

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p class="badge badge-danger">Pas de langues</p>
    <?php endif; ?>
  </div>


   <!--/.Langue-->
   <!--Structure organisation-->
   <div class="form-group">
    <label for="structure">Structure de l'organisation : </label>
    <input  disabled aria-describedby="errorStructure" type="text" class="form-control <?php $__errorArgs = ['structure'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="structure" value="<?php echo e(old('structure',$oph->structure)); ?>" placeholder="Bureau exécutif">
    <?php $__errorArgs = ['structure'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="form-text text-danger" id='structure'>
        <?php echo e($errors->first('structure')); ?>


    </small>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

  </div>


<!--/.Structure Organisation-->

                                
                            </div>
                            <div class="col">
                                <h5>Informations géographiques</h5>
                                <!--Région-->
                         <div class="form-group">
                            <label for="region_id">Région : </label>
                            <input  disabled aria-describedby="errorRegion_id" type="text" class="form-control <?php $__errorArgs = ['region_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="region_id" value="<?php echo e(old('region_id',$oph->region->libelle)); ?>" placeholder="Région">
                            
                                  
                          </div>
                
                
        <!--/.Région-->
        <!--Province-->
        <div class="form-group">
            <label for="province_id">Province : </label>
            
            <input  disabled aria-describedby="errorRegion_id" type="text" class="form-control <?php $__errorArgs = ['province_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="province_id" value="<?php echo e(old('province_id',$oph->province->libelle)); ?>" placeholder="Province">
                  
          </div>


<!--/.Province-->
<!--Communes-->
<div class="form-group">
    <label for="commune_id">Commune : </label>
    
    
        <input  disabled aria-describedby="errorCommune_id" type="text" class="form-control <?php $__errorArgs = ['commune_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="commune_id" value="<?php echo e(old('commune_id',$oph->commune->libelle)); ?>" placeholder="Commune">
        <?php $__errorArgs = ['commune_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <p class="help is-danger"><?php echo e($message); ?></p>
        
          
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          
  </div>


<!--/.Commune-->
<!--Zone d'intervention-->
<div class="form-group">
    <label for="zoneInt">Zone d'intervention : </label>
    <input  disabled aria-describedby="errorZoneInt" type="text" class="form-control <?php $__errorArgs = ['zoneInt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="zoneInt" value="<?php echo e(old('zoneInt',$oph->commune->libelle)); ?>" placeholder="Listez les zones d'intervention séparées par des pointss">
    <?php $__errorArgs = ['zoneInt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="form-text text-danger" id='errorActivite'>
        <?php echo e($errors->first('zoneInt')); ?>


    </small>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

  </div>

<!--/.Zone d'intervention-->
                                
                            </div>
                            <div class="col">
                                <h5>Responsable de la structure</h5>
                                <!--Nom du responsable-->
                <div class="form-group">
                    <label for="nom">Nom : </label>
                    <input  disabled aria-describedby="errorNom" type="text" class="form-control <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="nom" value="<?php echo e(old('nom',$oph->responsable->nom)); ?>" placeholder="Nom de famille  responsable">
                    <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="form-text text-danger" id='nom'>
                        <?php echo e($errors->first('nom')); ?>

          
                    </small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          
                  </div>
        
        
       <!--/.Nom du responsable-->
        <!--Prénom du responsable-->
        <div class="form-group">
            <label for="prenom">Prénom : </label>
            <input  disabled aria-describedby="errorPrenom" type="text" class="form-control <?php $__errorArgs = ['prenom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="prenom" value="<?php echo e(old('prenom',$oph->responsable->prenom)); ?>" placeholder="Prénom  responsable">
            <?php $__errorArgs = ['prenom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="form-text text-danger" id='prenom'>
                <?php echo e($errors->first('prenom')); ?>

  
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  
          </div>


<!--/.Prénom du responsable-->
 <!--Téléphone-->
 <div class="form-group">
    <label for="phone">Téléphone : </label>
    <input  disabled aria-describedby="errorPhone" type="text" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="phone" value="<?php echo e(old('phone',$oph->responsable->phone)); ?>" placeholder="Téléphone  responsable">
    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="form-text text-danger" id='phone'>
        <?php echo e($errors->first('phone')); ?>


    </small>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

  </div>


<!--/.Téléphone-->
<!--/.Sexe-->
<div class="form-group">
    <label for="sexe">Sexe : </label>
    
<input type="text" value="<?php echo e($oph->responsable->sexe); ?>" disabled>
</div>


 <!--/.Sexe-->
 <!--Profession-->
 <div class="form-group">
    <label for="profession">Profession : </label>
    <input  disabled aria-describedby="errorProfession" type="text" class="form-control <?php $__errorArgs = ['profession'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="profession" value="<?php echo e(old('profession',$oph->responsable->profession)); ?>" placeholder="Profession  responsable">
    <?php $__errorArgs = ['profession'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="form-text text-danger" id='profession'>
        <?php echo e($errors->first('profession')); ?>


    </small>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

  </div>
<!--/.Profession-->

                                
                            </div>
                            <div class="col">
                                <h5>Informations juridiques</h5>
                                <!--Récipissé-->
          <div class="form-group">
            <label for="numbRecipisse">REF. DU RECEPISSE : </label>
            <input  disabled aria-describedby="errorNumbRecipisse" type="text" class="form-control <?php $__errorArgs = ['numbRecipisse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="numbRecipisse" value="<?php echo e(old('numbRecipisse',$oph->numbRecipisse)); ?>" placeholder="Numéros de référence du récipissé">
            <?php $__errorArgs = ['numbRecipisse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="form-text text-danger" id='numbRecipisse'>
                <?php echo e($errors->first('numbRecipisse')); ?>

  
            </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  
          </div>
          <!--/.Récipissé-->
          <!--Statut juridique-->
 <div class="form-group">
    <label for="statut">Statut jurique : </label>
    <input  disabled aria-describedby="errorStatut" type="text" class="form-control <?php $__errorArgs = ['statut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="statut" value="<?php echo e(old('statut',$oph->statut)); ?>" placeholder="Statut juridique">
    <?php $__errorArgs = ['statut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="form-text text-danger" id='statut'>
        <?php echo e($errors->first('statut')); ?>


    </small>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

  </div>


<!--/.Statut-->
<!--Type d'OPH-->
<div class="form-group">
    <label for="type">Type d'OPH : </label>
    <input  disabled aria-describedby="errorType" type="text" class="form-control <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="type" value=" <?php echo e(old('type', $oph->type)); ?>" placeholder="Organisation de personnes handicapées">
    <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="form-text text-danger" id='type'>
        <?php echo e($errors->first('type')); ?>


    </small>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

  </div>
  <!--/.Type d'OPH-->
                                
                            </div>
                        </div>

                    </form>
                    
                        

                </div>
                <div class="card-footer">
                    <a href="<?php echo e(route('ophs.edit',$oph->id)); ?>" class="btn btn-warning">Modifier</a>
                </div>
            </div>

        </div>
        
            
        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\handidata\resources\views/handi-admin/adminoph/show.blade.php ENDPATH**/ ?>