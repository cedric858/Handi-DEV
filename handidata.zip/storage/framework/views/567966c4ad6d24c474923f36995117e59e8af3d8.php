<?php $__env->startSection('header'); ?>
    Détails de <strong><?php echo e($cheflieu->libelle); ?></strong> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="/admin">Accueil</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('cheflieus.index')); ?>">Liste chefs-lieux</a></li>
    <li class="breadcrumb-item active">Détails de <?php echo e($cheflieu->libelle); ?></li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!--Header de chef-lieu-->
<div class="row no-gutters">
    <div class="col-sm-12 col-md-4">
        <div class="card card-primary text-center">
            <div class="card-header">
                <h3 class="card-title">
                    Nombre de provinces dans ce chef-lieu
                </h3>


            </div>
            <div class="card-body ">

                <h3>
                    <?php echo e($cheflieu->provinces->count()); ?>

                </h3>

            </div>
            <div class="card-footer">
                <?php if($cheflieu->provinces->count() == 0): ?>
                    <a href="<?php echo e(route('provinces.create')); ?>" class="btn btn-info" title="Créer un indicateur"><i class="fas fa-plus"></i> En créer</a>
                    
                <?php else: ?>
                <a href="<?php echo e(route('provinces.index',['cheflieu'=>$cheflieu->id])); ?>" class="btn btn-info" title="Voir les provinces de ce domaine"><i class="fas fa-plus"></i> Aller aux provinces</a>
                    
                <?php endif; ?>
                

            </div>

        </div>
       


    </div>

        
</div>
<!--/.header de chef lieu-->

    <div class="row">
        <div class="col-md-8 col-offset-2">
            <div class="card">
                <div class="card-header">
                    <h3> <i class="fas fa-"></i> Les détails</h3>

                </div>
                <div class="card-body">
                        <form action="" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="region_id">Région:</label> 
                                <input aria-describedby="errorregion_id" type="text" 
                                class="form-control <?php $__errorArgs = ['region_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> "
                                 name="region_id" value="<?php echo e($cheflieu->region->libelle); ?>" disabled>
                            </div>
                           

                            <div class="form-group">
                                <label for="libelle">Libellé:</label> 
                                <input aria-describedby="errorlibelle" type="text" 
                                class="form-control "
                                 name="libelle" value="<?php echo e($cheflieu->libelle); ?>" disabled>
                            </div>


                        </form>
                        <a href="<?php echo e(route('cheflieus.edit',$cheflieu->id)); ?>" class="btn btn-warning" title="Modifier"><i class="fas fa-pencil"></i> Modifier</a>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\handidata\resources\views/handi-admin/admincheflieu/show.blade.php ENDPATH**/ ?>