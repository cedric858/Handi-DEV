<?php $__env->startSection('header'); ?>
    Détails langue
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="/admin">Accueil</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('langues.index')); ?>">Liste des langues</a></li>
    <li class="breadcrumb-item active">Détails langue</li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
        <div class="card-header">
            <h4 class="card-title">
                <?php echo e($item->libelle); ?>

            </h4>

        </div>
        <div class="card-body" >
            <div class="row ">
                <div class="col-sm-8">
                    <h5 class="card-title"><?php echo e($item->description?$item->description:"Pas de description"); ?></h5>
                    <p class="card-text">

                    </p>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-8 col-offset-2">
            <div class="card">
                <div class="card-header">
                    <h3> <i class="fas fa-"></i> Les détails</h3>

                </div>
                <div class="card-body">
                        <form action="" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="libelle">Libellé:</label> 
                                <input aria-describedby="errorlibelle" type="text" 
                                class="form-control <?php $__errorArgs = ['libelle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> "
                                 name="libelle" value="<?php echo e($item->libelle); ?>" disabled>
                            </div>
                        </form>
                        <a href="<?php echo e(route('langues.edit',$item->id)); ?>" class="btn btn-warning" title="Modifier"><i class="fas fa-pencil"></i> Modifier</a>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\handidata\resources\views/handi-admin/adminlangue/show.blade.php ENDPATH**/ ?>