<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TypeDesagregation extends Model
{
    //
}
